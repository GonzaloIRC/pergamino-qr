﻿import type { ExpoConfig } from 'expo-config';
const config: ExpoConfig = {
  name: 'PergaminoApp',
  slug: 'pergamino-app',
  version: '1.0.0',
  sdkVersion: '53.0.0',
  android: {
    package: 'com.gonzaloirc.pergaminoapp',
    compileSdkVersion: 35,
    targetSdkVersion: 35
  },
  extra: {
    EXPO_PUBLIC_USE_EMULATORS: process.env.EXPO_PUBLIC_USE_EMULATORS ?? 'false',
    EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_HOST: process.env.EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_HOST,
    EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_PORT: process.env.EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_PORT,
    EXPO_PUBLIC_FIRESTORE_EMULATOR_HOST: process.env.EXPO_PUBLIC_FIRESTORE_EMULATOR_HOST,
    EXPO_PUBLIC_FIRESTORE_EMULATOR_PORT: process.env.EXPO_PUBLIC_FIRESTORE_EMULATOR_PORT
  }
};
export default config;
