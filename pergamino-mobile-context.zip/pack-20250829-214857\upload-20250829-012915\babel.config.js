// filepath: babel.config.js
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      // Debe ir al final si usas reanimated
      'react-native-reanimated/plugin',
    ],
  };
};
