// src/MiniApp.js
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Linking } from 'react-native';

const MiniApp = () => {
  const abrirVersionWeb = () => {
    const url = 'http://localhost:8084';
    Linking.canOpenURL(url).then(supported => {
      if (supported) {
        Linking.openURL(url);
      } else {
        Alert.alert('Error', 'No se puede abrir el navegador');
      }
    });
  };

  const mostrarInfo = () => {
    Alert.alert(
      'Información',
      'Esta es la versión móvil simplificada para Expo Go.\n\nPara acceder a todas las funcionalidades (Firebase, cámara QR, backups), usa la versión web o crea un Development Build.',
      [{ text: 'OK' }]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Pergamino App</Text>
        <Text style={styles.subtitle}>Versión Móvil Simplificada</Text>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.message}>✅ Compatibilidad Móvil Confirmada</Text>
        
        <Text style={styles.info}>
          React Native funciona correctamente en tu dispositivo móvil.
        </Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.webButton} onPress={abrirVersionWeb}>
            <Text style={styles.buttonText}>🌐 Abrir Versión Web Completa</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.infoButton} onPress={mostrarInfo}>
            <Text style={styles.buttonText}>ℹ️ Más Información</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.featureList}>
          <Text style={styles.featureTitle}>🚀 Funciones Disponibles en Web:</Text>
          <Text style={styles.featureItem}>• Gestión completa de clientes</Text>
          <Text style={styles.featureItem}>• Registro de consumos y puntos</Text>
          <Text style={styles.featureItem}>• Sistema de canjes</Text>
          <Text style={styles.featureItem}>• Panel administrativo</Text>
          <Text style={styles.featureItem}>• Backups y estadísticas</Text>
          <Text style={styles.featureItem}>• Escáner QR (cámara web)</Text>
        </View>

        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>📱 Estado Móvil</Text>
          <Text style={styles.statusText}>
            ✅ React Native: Funcionando{'\n'}
            ✅ Expo Go: Compatible{'\n'}
            ⚠️ Funciones avanzadas: Solo en web{'\n'}
            💡 Solución: Development Build
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#8B4513',
    padding: 40,
    alignItems: 'center',
    paddingTop: 60,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: 'white',
    opacity: 0.9,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  message: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#28a745',
    textAlign: 'center',
    marginBottom: 15,
  },
  info: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 24,
  },
  buttonContainer: {
    marginBottom: 30,
  },
  webButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 10,
  },
  infoButton: {
    backgroundColor: '#28a745',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  featureList: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
    elevation: 2,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  featureItem: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
    paddingLeft: 10,
  },
  statusCard: {
    backgroundColor: '#e8f5e8',
    padding: 20,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#28a745',
  },
  statusTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#155724',
    marginBottom: 10,
  },
  statusText: {
    fontSize: 14,
    color: '#155724',
    lineHeight: 22,
  },
});

export default MiniApp;
