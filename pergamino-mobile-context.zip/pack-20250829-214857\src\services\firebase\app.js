﻿import { Platform } from 'react-native';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import {
  getAuth,
  initializeAuth,
  connectAuthEmulator,
  getReactNativePersistence
} from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';

const firebaseConfig = {
  apiKey: "dummy",
  authDomain: "dummy.firebaseapp.com",
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID || "demo-pergamino",
  storageBucket: "dummy.appspot.com",
  messagingSenderId: "0",
  appId: "1:0:web:0"
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

// Auth con persistencia en RN (y sin reinit si ya existe)
let auth;
try {
  auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage)
  });
} catch {
  auth = getAuth(app);
}

const db = getFirestore(app);

// Emuladores (solo si EXPO_PUBLIC_USE_EMULATORS === "true")
const useEmus = (process.env.EXPO_PUBLIC_USE_EMULATORS || 'false').toLowerCase() === 'true';
if (useEmus) {
  const ahost = process.env.EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_HOST || '127.0.0.1';
  const aport = process.env.EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_PORT || '9099';
  const fhost = process.env.EXPO_PUBLIC_FIRESTORE_EMULATOR_HOST || '127.0.0.1';
  const fport = process.env.EXPO_PUBLIC_FIRESTORE_EMULATOR_PORT || '8080';
  try { connectAuthEmulator(auth, `http://${ahost}:${aport}`); } catch {}
  try { connectFirestoreEmulator(db, fhost, Number(fport)); } catch {}
}

export { app, auth, db };
export default app;
