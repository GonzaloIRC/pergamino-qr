﻿const { getDefaultConfig } = require("expo/metro-config");
/** @type {import('metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);
// Forzar resolución estable de node_modules (evita tomar TS fuente)
config.resolver = {
  ...config.resolver,
  resolverMainFields: ["react-native", "browser", "main"],
};
module.exports = config;
