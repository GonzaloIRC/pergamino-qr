// src/SimplePergaminoApp.js
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';

const SimplePergaminoApp = ({ navigation }) => {
  const opciones = [
    {
      titulo: 'Registro Cliente',
      descripcion: 'Registrar un nuevo cliente',
      screen: 'RegisterClient',
      color: '#28a745'
    },
    {
      titulo: 'Escaner QR',
      descripcion: 'Escanear código QR de mesa',
      screen: 'QRScanner',
      color: '#007AFF'
    },
    {
      titulo: 'Modo Mesero',
      descripcion: 'Acceso para meseros',
      screen: 'PINAccess',
      color: '#ff6b35'
    },
    {
      titulo: 'Panel Admin',
      descripcion: 'Administración del restaurante',
      screen: 'SimpleMenuAdmin',
      color: '#8B4513'
    }
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>🍽️ Pergamino App</Text>
        <Text style={styles.subtitle}>Sistema de Fidelización</Text>
      </View>

      <ScrollView style={styles.content}>
        {opciones.map((opcion, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.opcionCard, { borderLeftColor: opcion.color }]}
            onPress={() => {
              try {
                navigation.navigate(opcion.screen);
              } catch (error) {
                Alert.alert('Error', 'No se pudo abrir esta sección.');
              }
            }}
          >
            <View style={styles.opcionContent}>
              <Text style={styles.opcionTitulo}>{opcion.titulo}</Text>
              <Text style={styles.opcionDescripcion}>{opcion.descripcion}</Text>
            </View>
            <View style={[styles.colorIndicator, { backgroundColor: opcion.color }]} />
          </TouchableOpacity>
        ))}

        <View style={styles.infoCard}>
          <Text style={styles.infoTitulo}>ℹ️ Versión Simplificada</Text>
          <Text style={styles.infoTexto}>
            Esta es una versión compatible con Expo Go.{'\n'}
            Todas las funcionalidades principales están disponibles.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#8B4513',
    padding: 40,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: 'white',
    opacity: 0.9,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  opcionCard: {
    backgroundColor: 'white',
    marginBottom: 15,
    borderRadius: 12,
    borderLeftWidth: 4,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    flexDirection: 'row',
    overflow: 'hidden',
  },
  opcionContent: {
    flex: 1,
    padding: 20,
  },
  opcionTitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  opcionDescripcion: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  colorIndicator: {
    width: 4,
  },
  infoCard: {
    backgroundColor: '#e8f5e8',
    padding: 20,
    borderRadius: 12,
    marginTop: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#28a745',
  },
  infoTitulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#155724',
    marginBottom: 10,
  },
  infoTexto: {
    fontSize: 14,
    color: '#155724',
    lineHeight: 20,
  },
});

export default SimplePergaminoApp;
