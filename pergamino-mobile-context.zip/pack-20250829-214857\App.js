﻿import React, { useState, useCallback } from 'react';
import app, { auth, db } from './src/services/firebase/app';
import { View, Text, Pressable, StatusBar, StyleSheet, FlatList } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import AppNavigator from './src/navigation/AppNavigator';
import Scanner from './src/components/BarcodeScanner/Scanner';

/**
 * Por qué: flujo mínimo funcional sin dependencias extra.
 * - Pantalla Home con botón para abrir el escáner.
 * - Muestra el último código y un historial en la sesión.
 */
export default function App() {
  const [route, setRoute] = useState('home'); // 'home' | 'scan'
  const [lastScan, setLastScan] = useState(null);
  const [history, setHistory] = useState([]);

  const openScanner = useCallback(() => setRoute('scan'), []);
  const closeScanner = useCallback(() => setRoute('home'), []);

  const handleScan = useCallback(
    (payload) => {
      setLastScan(payload);
      setHistory((h) => [{ id: String(Date.now()), ...payload }, ...h].slice(0, 25));
      setRoute('home');
      console.log('barcode', payload.type, payload.data);
    },
    []
  );

  if (route === 'scan') {
    return (
      <View style={{ flex: 1 }}>
        <StatusBar />
        <Scanner onClose={closeScanner} onScan={handleScan} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <View style={styles.container}>
        <StatusBar />
        <Text style={styles.title}>Pergamino App</Text>
        <Pressable style={styles.cta} onPress={openScanner}>
          <Text style={styles.ctaText}>Abrir escáner</Text>
        </Pressable>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Última lectura</Text>
          {lastScan ? (
            <View>
              <Text style={styles.kv}>
                <Text style={styles.k}>Tipo:</Text> {lastScan.type}
              </Text>
              <Text style={styles.kv}>
                <Text style={styles.k}>Dato:</Text> {lastScan.data}
              </Text>
              <Text style={styles.kv}>
                <Text style={styles.k}>Hora:</Text> {new Date(lastScan.ts).toLocaleString()}
              </Text>
            </View>
          ) : (
            <Text style={styles.muted}>Aún sin lecturas</Text>
          )}
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Historial (sesión)</Text>
          <FlatList
            data={history}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.row}>
                <Text style={styles.rowType}>{item.type}</Text>
                <Text style={styles.rowData} numberOfLines={1}>
                  {item.data}
                </Text>
              </View>
            )}
            ListEmptyComponent={<Text style={styles.muted}>Vacío</Text>}
            style={{ maxHeight: 260 }}
          />
        </View>
      </View>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 48 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 16 },
  cta: {
    backgroundColor: '#111',
    borderRadius: 10,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignSelf: 'flex-start',
    marginBottom: 16,
  },
  ctaText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginTop: 12, elevation: 2 },
  cardTitle: { fontSize: 16, fontWeight: '600', marginBottom: 8 },
  kv: { marginBottom: 4 },
  k: { fontWeight: '700' },
  muted: { color: '#666' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 6,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#eee',
  },
  rowType: { fontSize: 12, fontWeight: '700', width: 80 },
  rowData: { flex: 1, fontSize: 12 },
});
