// filepath: src/screens/MyQR.js
import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import { normalizeRut, isValidRut } from '../utils/rut';
import { getClientRut, setClientRut, clearClientRut } from '../services/session';

export default function MyQR({ onDone }) {
  const [rut, setRut] = useState('');

  useEffect(() => {
    (async () => { const r = await getClientRut(); if (r) setRut(r); })();
  }, []);

  const saveRut = async () => {
    const n = normalizeRut(rut);
    if (!isValidRut(n)) return Alert.alert('RUT inválido', 'Ejemplo: 12.345.678-5');
    setRut(n);
    await setClientRut(n);
  };

  const payload = rut ? JSON.stringify({ v: 1, type: 'client', rut }) : '';

  return (
    <View style={{ flex: 1, padding: 20, gap: 12, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: 20, fontWeight: '700' }}>Mi QR de Cliente</Text>
      <Text style={{ textAlign: 'center' }}>Este código será escaneado por el mesero para registrar tu visita y puntos.</Text>

      <TextInput
        placeholder="RUT (12.345.678-5)"
        value={rut}
        autoCapitalize="characters"
        onChangeText={setRut}
        style={{ borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 12, alignSelf: 'stretch' }}
      />

      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Button title="Guardar RUT" onPress={saveRut} />
        <Button title="Borrar" onPress={async () => { await clearClientRut(); setRut(''); }} />
      </View>

      {payload ? (
        <View style={{ marginTop: 20, padding: 12, borderRadius: 12, backgroundColor: '#fff' }}>
          <QRCode value={payload} size={220} />
        </View>
      ) : (
        <Text style={{ color: '#666', marginTop: 12 }}>Ingresa y guarda tu RUT para ver tu QR</Text>
      )}

      <View style={{ height: 24 }} />
      <Button title="Volver" onPress={() => onDone?.()} />
    </View>
  );
}
