// filepath: src/services/firebase/clients.js
import { auth, db } from './app';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { normalizeRut, isValidRut } from '../../utils/rut';

export async function registerClient({ nombre, apellido, rut, email, fechaNacimiento, password }) {
  const rutN = normalizeRut(rut);
  if (!isValidRut(rutN)) throw new Error('RUT inválido');

  // Evita sobrescribir un cliente ya existente
  const ref = doc(db, 'clientes', rutN);
  const snap = await getDoc(ref);
  if (snap.exists()) throw new Error('El RUT ya está registrado');

  // Crea usuario Auth (email+password)
  await createUserWithEmailAndPassword(auth, email, password);

  // Crea documento del cliente
  const cliente = {
    nombre,
    apellido,
    rut: rutN,
    email,
    fechaNacimiento,
    puntos: 0,
    categoria: 'cliente',
    walletActivo: false,
    fechaRegistro: serverTimestamp(),
  };
  await setDoc(ref, cliente);
  return cliente;
}
