// filepath: metro.config.js
const { getDefaultConfig } = require('expo/metro-config');

/** @type {import('metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

// Forzar que Metro resuelva los builds compilados de los paquetes
// y NO los sources TypeScript dentro de node_modules
config.resolver = {
  ...config.resolver,
  resolverMainFields: ['react-native', 'browser', 'main'],
};

module.exports = config;
