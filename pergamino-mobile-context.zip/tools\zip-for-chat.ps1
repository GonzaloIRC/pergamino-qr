# Zip For Chat — Pergamino App (ASCII-safe)
param([string]$OutZip = "pergamino-mobile-context.zip")

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Info([string]$m){ Write-Host ("==> " + $m) -ForegroundColor Cyan }
function Ok([string]$m){ Write-Host ("OK  " + $m) -ForegroundColor Green }
function Warn([string]$m){ Write-Host ("!!  " + $m) -ForegroundColor Yellow }

$root = (Get-Location).Path
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
$st = Join-Path $root ("pack-" + $ts)
New-Item -ItemType Directory -Path $st -Force | Out-Null

# Archivos/paths esenciales a incluir en el ZIP
$globs = @(
  "package.json","package-lock.json","yarn.lock","pnpm-lock.yaml",
  "app.config.ts","app.json","index.js","App.js",
  "babel.config.js","metro.config.js",
  "eas.json","tsconfig.json","jsconfig.json","jest.config.*",
  "README.md","RESUMEN.md","PLAN.md",
  "src\**\*","firebase\**\*","emulator-data\**\*",
  ".vscode\**\*",".maestro\**\*","tools\**\*","scripts\**\*",
  "android\app\src\main\AndroidManifest.xml",
  "android\app\src\debug\AndroidManifest.xml",
  "android\build.gradle","android\settings.gradle","android\gradle.properties",
  "android\gradle\wrapper\gradle-wrapper.properties",
  "docs\**\*","tests\**\*","e2e\**\*",
  ".env.local",".env.staging",".firebaserc","firebase.json",
  "logs\expo-run-android.txt"
)

# Excluir basuras pesadas
$excludeRe = "\\node_modules\\|\\.git\\|\\android\\.gradle\\|\\android\\build\\|\\.gradle\\|\\build\\|\\dist\\|\\eas-build-local\\|\\pods\\|\\ios\\build\\"

$missing = New-Object System.Collections.ArrayList

foreach($g in $globs){
  $path = Join-Path $root $g
  $items = Get-ChildItem -Path $path -Recurse -Force -ErrorAction SilentlyContinue |
    Where-Object { -not $_.PSIsContainer -and $_.FullName -notmatch $excludeRe }
  if(-not $items){
    [void]$missing.Add($g)
  }else{
    foreach($it in $items){
      $full = $it.FullName
      $rel = $full.Substring($root.Length)
      if($rel -match '^[\\/]+'){ $rel = $rel -replace '^[\\/]+','' }
      $dst = Join-Path $st $rel
      New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
      Copy-Item $full $dst -Force
    }
  }
}

# Si faltan configs de Babel/Metro, generar versiones canónicas SOLO dentro del staging
$babelSt = Join-Path $st "babel.config.js"
if(-not (Test-Path $babelSt)){
  @"
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: ['react-native-reanimated/plugin'],
  };
};
"@ | Set-Content -Path $babelSt -Encoding UTF8
}

$metroSt = Join-Path $st "metro.config.js"
if(-not (Test-Path $metroSt)){
  @"
const { getDefaultConfig } = require('expo/metro-config');
const config = getDefaultConfig(__dirname);
config.resolver = { ...config.resolver, resolverMainFields: ['react-native','browser','main'] };
module.exports = config;
"@ | Set-Content -Path $metroSt -Encoding UTF8
}

# Sanear .env* (no subir secretos)
Get-ChildItem $st -Recurse -Include ".env*", ".env.local", ".env.staging" -ErrorAction SilentlyContinue | ForEach-Object {
  (Get-Content $_.FullName) -replace "=(.*)$","=REDACTED" | Set-Content $_.FullName -Encoding UTF8
}

# Reporte de faltantes (no crítico)
if($missing.Count -gt 0){
  "Faltantes (FYI, puede ser normal si no existen en tu repo):" | Set-Content (Join-Path $st "MISSING.txt") -Encoding UTF8
  $missing | Add-Content (Join-Path $st "MISSING.txt")
}

# Comprimir
$zip = Join-Path $root $OutZip
if(Test-Path $zip){ Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $st "*") -DestinationPath $zip -CompressionLevel Optimal

Ok ("ZIP listo: " + (Resolve-Path $zip).Path)
Ok ("Staging: " + $st)
