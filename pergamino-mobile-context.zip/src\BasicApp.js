// src/BasicApp.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const BasicApp = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Pergamino App</Text>
        <Text style={styles.subtitle}>Versión Móvil Básica</Text>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.successMessage}>✅ ¡Éxito!</Text>
        <Text style={styles.message}>
          React Native funciona correctamente en Expo Go
        </Text>
        
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Estado:</Text>
          <Text style={styles.infoText}>• React Native: Funcionando</Text>
          <Text style={styles.infoText}>• Expo Go: Compatible</Text>
          <Text style={styles.infoText}>• Errores: Ninguno</Text>
        </View>
        
        <View style={styles.instructionBox}>
          <Text style={styles.instructionTitle}>Para funciones completas:</Text>
          <Text style={styles.instructionText}>
            Abre la versión web en tu navegador:
          </Text>
          <Text style={styles.urlText}>http://localhost:8085</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    backgroundColor: '#8B4513',
    padding: 50,
    alignItems: 'center',
    paddingTop: 70,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: 'white',
    opacity: 0.9,
  },
  content: {
    flex: 1,
    padding: 30,
    alignItems: 'center',
  },
  successMessage: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#28a745',
    marginBottom: 20,
    textAlign: 'center',
  },
  message: {
    fontSize: 18,
    color: '#495057',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 26,
  },
  infoBox: {
    backgroundColor: '#d4edda',
    padding: 20,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#28a745',
    marginBottom: 30,
    width: '100%',
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#155724',
    marginBottom: 12,
  },
  infoText: {
    fontSize: 16,
    color: '#155724',
    marginBottom: 6,
    paddingLeft: 10,
  },
  instructionBox: {
    backgroundColor: '#d1ecf1',
    padding: 20,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#17a2b8',
    width: '100%',
  },
  instructionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0c5460',
    marginBottom: 12,
  },
  instructionText: {
    fontSize: 16,
    color: '#0c5460',
    marginBottom: 8,
  },
  urlText: {
    fontSize: 16,
    color: '#0c5460',
    fontWeight: 'bold',
    fontFamily: 'monospace',
    backgroundColor: '#bee5eb',
    padding: 8,
    borderRadius: 6,
    textAlign: 'center',
  },
});

export default BasicApp;
