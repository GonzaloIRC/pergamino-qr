// src/RegisterClient.js
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import { auth, db } from '../services/firebase/app';
import { collection, addDoc, serverTimestamp, query, where, getDocs } from 'firebase/firestore';

const RegisterClient = ({ navigation }) => {
  const [formData, setFormData] = useState({
    nombre: '',
    dni: '',
    telefono: '',
    email: '',
    fechaNacimiento: '',
    genero: '',
  });
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateForm = () => {
    if (!formData.nombre.trim()) {
      Alert.alert('Error', 'El nombre es obligatorio');
      return false;
    }
    if (!formData.dni.trim()) {
      Alert.alert('Error', 'El DNI es obligatorio');
      return false;
    }
    if (formData.dni.length < 7 || formData.dni.length > 10) {
      Alert.alert('Error', 'El DNI debe tener entre 7 y 10 dígitos');
      return false;
    }
    if (!formData.telefono.trim()) {
      Alert.alert('Error', 'El teléfono es obligatorio');
      return false;
    }
    if (!formData.email.trim()) {
      Alert.alert('Error', 'El email es obligatorio');
      return false;
    }
    return true;
  };

  const checkDniExists = async (dni) => {
    try {
      const q = query(collection(db, 'clientes'), where('dni', '==', dni));
      const querySnapshot = await getDocs(q);
      return !querySnapshot.empty;
    } catch (error) {
      console.error('Error verificando DNI:', error);
      return false;
    }
  };

  const generateClientQR = (clienteId, dni) => {
    return JSON.stringify({
      clienteId: clienteId,
      dni: dni,
      restaurante: 'Pergamino',
      tipo: 'cliente',
      timestamp: Date.now()
    });
  };

  const handleRegister = async () => {
    if (!validateForm()) return;

    setLoading(true);
    try {
      // Verificar si el DNI ya existe
      const dniExists = await checkDniExists(formData.dni);
      if (dniExists) {
        Alert.alert('Error', 'Ya existe un cliente registrado con este DNI');
        setLoading(false);
        return;
      }

      // Registrar cliente en Firebase
      const clienteData = {
        ...formData,
        fechaRegistro: serverTimestamp(),
        puntos: 0,
        estado: 'activo',
        totalVisitas: 0,
        ultimaVisita: null
      };

      const docRef = await addDoc(collection(db, 'clientes'), clienteData);
      
      // Generar QR personal del cliente
      const qrData = generateClientQR(docRef.id, formData.dni);
      
      Alert.alert(
        'Registro Exitoso',
        `¡Bienvenido ${formData.nombre}! Tu cuenta ha sido creada exitosamente.`,
        [
          {
            text: 'Ver mi QR Personal',
            onPress: () => navigation.navigate('ClienteQR', { 
              clienteId: docRef.id,
              qrData: qrData,
              clienteNombre: formData.nombre,
              puntos: 0
            })
          }
        ]
      );
    } catch (error) {
      console.error('Error al registrar cliente:', error);
      Alert.alert('Error', 'No se pudo completar el registro. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Registro de Cliente</Text>
        <Text style={styles.subtitle}>Crea tu cuenta para obtener tu QR personal</Text>
      </View>

      <View style={styles.form}>
        <Text style={styles.label}>Nombre Completo *</Text>
        <TextInput
          style={styles.input}
          value={formData.nombre}
          onChangeText={(value) => handleInputChange('nombre', value)}
          placeholder="Ingresa tu nombre completo"
        />

        <Text style={styles.label}>DNI / Cédula *</Text>
        <TextInput
          style={styles.input}
          value={formData.dni}
          onChangeText={(value) => handleInputChange('dni', value)}
          placeholder="Ingresa tu número de documento"
          keyboardType="numeric"
          maxLength={10}
        />

        <Text style={styles.label}>Teléfono *</Text>
        <TextInput
          style={styles.input}
          value={formData.telefono}
          onChangeText={(value) => handleInputChange('telefono', value)}
          placeholder="Ingresa tu número de teléfono"
          keyboardType="phone-pad"
        />

        <Text style={styles.label}>Email *</Text>
        <TextInput
          style={styles.input}
          value={formData.email}
          onChangeText={(value) => handleInputChange('email', value)}
          placeholder="Ingresa tu email"
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <Text style={styles.label}>Fecha de Nacimiento</Text>
        <TextInput
          style={styles.input}
          value={formData.fechaNacimiento}
          onChangeText={(value) => handleInputChange('fechaNacimiento', value)}
          placeholder="DD/MM/AAAA"
        />

        <Text style={styles.label}>Género</Text>
        <TextInput
          style={styles.input}
          value={formData.genero}
          onChangeText={(value) => handleInputChange('genero', value)}
          placeholder="Masculino/Femenino/Otro"
        />

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleRegister}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? 'Registrando...' : 'Registrarse'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, styles.backButton]}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.buttonText}>Volver</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#8B4513',
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 18,
    color: 'white',
  },
  form: {
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    marginTop: 15,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: 'white',
  },
  button: {
    backgroundColor: '#8B4513',
    padding: 15,
    borderRadius: 8,
    marginTop: 20,
    alignItems: 'center',
  },
  backButton: {
    backgroundColor: '#666',
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default RegisterClient;
