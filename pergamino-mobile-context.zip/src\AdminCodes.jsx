import React from "react";

function AdminCodes() {
  return null; // Puedes cambiar esto por una interfaz de administrador en el futuro
}

export default AdminCodes;
