// src/UltraSimpleApp.js
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView,
} from 'react-native';

const UltraSimpleApp = () => {
  const handlePress = (option) => {
    Alert.alert('Función', `Has presionado: ${option}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Pergamino App</Text>
        <Text style={styles.subtitle}>Versión Ultra Simple</Text>
      </View>

      <ScrollView style={styles.content}>
        <Text style={styles.sectionTitle}>🏪 Opciones Principales</Text>
        
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#007AFF' }]}
          onPress={() => handlePress('Clientes')}
        >
          <Text style={styles.buttonText}>👥 Gestión de Clientes</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#28a745' }]}
          onPress={() => handlePress('Consumos')}
        >
          <Text style={styles.buttonText}>💰 Registrar Consumo</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#ff6b35' }]}
          onPress={() => handlePress('Canjes')}
        >
          <Text style={styles.buttonText}>🎁 Canjes de Puntos</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#8B4513' }]}
          onPress={() => handlePress('Admin')}
        >
          <Text style={styles.buttonText}>⚙️ Panel Admin</Text>
        </TouchableOpacity>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>ℹ️ Información</Text>
          <Text style={styles.infoText}>
            Esta es una versión ultra simplificada para probar la compatibilidad con Expo Go.
            {'\n\n'}Si esta versión funciona, significa que el problema está en las dependencias más complejas.
          </Text>
        </View>

        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>✅ Estado de la App</Text>
          <Text style={styles.statusText}>
            • React Native: Funcionando{'\n'}
            • Expo Go: Compatible{'\n'}
            • Navegación: Básica{'\n'}
            • Firebase: Deshabilitado temporalmente
          </Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#8B4513',
    padding: 30,
    alignItems: 'center',
    paddingTop: 50, // Espacio adicional para status bar
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: 'white',
    opacity: 0.9,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  button: {
    padding: 20,
    borderRadius: 12,
    marginBottom: 15,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  infoCard: {
    backgroundColor: '#e3f2fd',
    padding: 20,
    borderRadius: 12,
    marginTop: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#2196f3',
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1565c0',
    marginBottom: 10,
  },
  infoText: {
    fontSize: 14,
    color: '#1565c0',
    lineHeight: 22,
  },
  statusCard: {
    backgroundColor: '#e8f5e8',
    padding: 20,
    borderRadius: 12,
    marginTop: 15,
    marginBottom: 30,
    borderLeftWidth: 4,
    borderLeftColor: '#28a745',
  },
  statusTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#155724',
    marginBottom: 10,
  },
  statusText: {
    fontSize: 14,
    color: '#155724',
    lineHeight: 22,
  },
});

export default UltraSimpleApp;
