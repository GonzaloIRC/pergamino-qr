﻿/**
 * Firebase singleton para React Native (Expo).
 * - Evita "duplicate-app".
 * - Usa AsyncStorage para persistir sesión.
 * - Conecta a Emuladores si EXPO_PUBLIC_USE_EMULATORS === "true".
 */
import { Platform } from 'react-native';
import { getApps, getApp, initializeApp } from 'firebase/app';
import {
  getAuth,
  initializeAuth,
  getReactNativePersistence,
  connectAuthEmulator,
  browserLocalPersistence,
} from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Config real (puedes sobreescribir con ENV si quieres)
const firebaseConfig = {
  apiKey: 'AIzaSyCeQU3rKVlDKhWkyF5mFqDp9NYDMPAfOt4',
  authDomain: 'codigos-pergamino.firebaseapp.com',
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID ?? 'codigos-pergamino',
  storageBucket: 'codigos-pergamino.firebasestorage.app',
  messagingSenderId: '849867276398',
  appId: '1:849867276398:web:0d9273b3c5130447f3a67f',
  measurementId: 'G-GT982TM94R', // NO usar getAnalytics en RN (web-only)
};

// Nunca llames initializeApp fuera de ESTE módulo.
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

// Auth con persistencia en RN (AsyncStorage)
let auth;
try {
  // RN: usa initializeAuth una sola vez para fijar persistencia
  auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage),
  });
} catch (e) {
  // Si ya estaba inicializado en otro punto (no debería), caemos a getAuth
  auth = getAuth(app);
}

// Firestore
const db = getFirestore(app);

// Emuladores (solo si EXPO_PUBLIC_USE_EMULATORS === "true")
const USE_EMU = String(process.env.EXPO_PUBLIC_USE_EMULATORS ?? 'false') === 'true';
if (USE_EMU) {
  const hostFromEnv = process.env.EXPO_PUBLIC_FIREBASE_EMULATOR_HOST;
  // En Android emulator usa 10.0.2.2 para hablar con el host
  const defaultHost = Platform.OS === 'android' ? '10.0.2.2' : 'localhost';
  const EMU_HOST = hostFromEnv && hostFromEnv.length > 0 ? hostFromEnv : defaultHost;
  const AUTH_PORT = Number(process.env.EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_PORT ?? '9099');
  const FS_PORT = Number(process.env.EXPO_PUBLIC_FIRESTORE_EMULATOR_PORT ?? '8080');
  try { connectAuthEmulator(auth, `http://${EMU_HOST}:${AUTH_PORT}`); } catch {}
  try { connectFirestoreEmulator(db, EMU_HOST, FS_PORT); } catch {}
}

export { app, auth, db };
export default app;
