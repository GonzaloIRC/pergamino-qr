// filepath: src/services/session.js
// Persistencia mínima en el dispositivo para datos del cliente
import AsyncStorage from '@react-native-async-storage/async-storage';

const RUT_KEY = 'client.rut';

export async function setClientRut(rut) {
  try { await AsyncStorage.setItem(RUT_KEY, rut); } catch {}
}

export async function getClientRut() {
  try { return (await AsyncStorage.getItem(RUT_KEY)) || ''; } catch { return ''; }
}

export async function clearClientRut(){
  try { await AsyncStorage.removeItem(RUT_KEY); } catch {}
}
