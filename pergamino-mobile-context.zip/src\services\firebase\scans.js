// filepath: src/services/firebase/scans.js
import { db } from './app';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';

export async function saveScan(payload) {
  const doc = {
    ...payload,
    createdAt: serverTimestamp(),
  };
  await addDoc(collection(db, 'scans'), doc);
}
