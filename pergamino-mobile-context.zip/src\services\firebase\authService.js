// filepath: src/services/firebase/authService.js
import { auth, db } from './app';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

/**
 * Registra cliente (Auth + perfil en Firestore en /clientes/{rut}).
 */
export async function registerClient({ nombre, apellido, rut, email, password, fechaNacimiento }) {
  if (!nombre || !apellido || !rut || !email || !password) {
    throw new Error('Faltan campos obligatorios');
  }
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const ref = doc(db, 'clientes', rut.trim());
  await setDoc(ref, {
    uid: userCredential.user.uid,
    email,
    rut,
    nombre,
    createdAt: new Date().toISOString(),
  });
  return cred.user;
}

 export async function login(email, password) {
   return signInWithEmailAndPassword(auth, email, password);
}

export function logout() {
  return signOut(auth);
}
