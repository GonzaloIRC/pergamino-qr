Write-Host "\n==== INICIANDO SCRIPT DE EMULADORES ====" -ForegroundColor Magenta
Write-Host "Directorio actual: $((Get-Location).Path)" -ForegroundColor Magenta

param(
  [string]$Project = "demo-pergamino",
  [string]$ConfigPath,
  [switch]$Debug
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Info([string]$m){ Write-Host ("==> " + $m) -ForegroundColor Cyan }
function Ok([string]$m){ Write-Host ("OK  " + $m) -ForegroundColor Green }
function Warn([string]$m){ Write-Host ("!!  " + $m) -ForegroundColor Yellow }
function Die([string]$m){ Write-Host ("XX  " + $m) -ForegroundColor Red; exit 1 }

# 0) Ubicación y config
$repo = Get-Location
if(-not $ConfigPath){
  # Asume firebase.json en la raíz del repo
  $ConfigPath = Join-Path $repo.Path 'firebase.json'
}
if(-not (Test-Path $ConfigPath)){ Die "No se encontró firebase.json en: $ConfigPath. Ejecuta este script desde la RAÍZ del repo o pasa -ConfigPath" }

# 1) Determinar IP LAN (para usarla en .env cuando pruebes en teléfono real)
function Get-LanIp {
  try {
    $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
      Where-Object { $_.IPAddress -notmatch '^127\.' -and $_.IPAddress -notmatch '^169\.254\.' -and $_.PrefixOrigin -ne 'WellKnown' }
    # Heurística: prioriza Wi-Fi / Ethernet
    $cand = $ips | Sort-Object {
      if($_.InterfaceAlias -match 'Wi-Fi|WLAN|Wireless'){0}
      elseif($_.InterfaceAlias -match 'Ethernet'){1}
      else{2}
    }
    return ($cand | Select-Object -First 1).IPAddress
  } catch { return $null }
}
$lan = Get-LanIp
if($lan){ Ok "IP LAN detectada: $lan" } else { Warn "No se pudo detectar IP LAN (opcional)" }

# 2) Sugerir variables .env.local
Write-Host "\nSugerencia .env.local (para teléfono real):" -ForegroundColor DarkGray
Write-Host "EXPO_PUBLIC_USE_EMULATORS=true" -ForegroundColor DarkGray
if($lan){
  Write-Host "EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_HOST=$lan" -ForegroundColor DarkGray
  Write-Host "EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_PORT=9099" -ForegroundColor DarkGray
  Write-Host "EXPO_PUBLIC_FIRESTORE_EMULATOR_HOST=$lan" -ForegroundColor DarkGray
  Write-Host "EXPO_PUBLIC_FIRESTORE_EMULATOR_PORT=8080" -ForegroundColor DarkGray
}

# 3) Asegurar firebase-tools local
try { (npx firebase-tools --version) | Out-Null } catch {
  Info "Instalando firebase-tools (devDependency)"
  npm i -D firebase-tools@latest | Out-Null
}

# 4) Descargar emuladores si faltan
Info "Descargando emuladores si faltan"
try { npx firebase-tools setup:emulators:firestore | Out-Null } catch {}
try { npx firebase-tools setup:emulators:ui | Out-Null } catch {}
try { npx firebase-tools setup:emulators:auth | Out-Null } catch {}

# 5) Lanzar emuladores (Auth + Firestore)
$cmd = @('firebase-tools','emulators:start','--only','auth,firestore','--project', $Project, '--config', $ConfigPath)
if($Debug){ $cmd += '--debug' }

Info "Iniciando emuladores (Proyecto: $Project)"
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = 'npx'
$psi.ArgumentList.AddRange($cmd)
$psi.UseShellExecute = $false
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$proc = New-Object System.Diagnostics.Process
$proc.StartInfo = $psi
$null = $proc.Start()

# stream de salida
Register-ObjectEvent -InputObject $proc -EventName OutputDataReceived -Action { if($EventArgs.Data){ Write-Host $EventArgs.Data } } | Out-Null
Register-ObjectEvent -InputObject $proc -EventName ErrorDataReceived -Action { if($EventArgs.Data){ Write-Host $EventArgs.Data -ForegroundColor Red } } | Out-Null
$proc.BeginOutputReadLine(); $proc.BeginErrorReadLine()

Ok "Abriendo UI del emulador (solo en este PC): http://127.0.0.1:4000"

# Mantener la consola viva mientras emuladores corren
while(-not $proc.HasExited){ Start-Sleep -Milliseconds 300 }
exit $proc.ExitCode
