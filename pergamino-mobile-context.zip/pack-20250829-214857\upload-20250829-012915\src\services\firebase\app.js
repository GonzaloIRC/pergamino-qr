﻿import { initializeApp, getApps } from 'firebase/app';
import { initializeAuth, getReactNativePersistence, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

const projectId = process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID || 'demo-pergamino';
const useEmu = (process.env.EXPO_PUBLIC_USE_EMULATORS || 'true') === 'true';
const authHost = process.env.EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_HOST || '127.0.0.1';
const authPort = Number(process.env.EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR_PORT || '9099');
const fsHost = process.env.EXPO_PUBLIC_FIRESTORE_EMULATOR_HOST || '127.0.0.1';
const fsPort = Number(process.env.EXPO_PUBLIC_FIRESTORE_EMULATOR_PORT || '8080');

// Config mínima para uso con emuladores
const firebaseConfig = { apiKey: 'demo', appId: 'demo', projectId };

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

// Persistencia en RN con AsyncStorage
export const auth = initializeAuth(app, { persistence: getReactNativePersistence(AsyncStorage) });
export const db = getFirestore(app);

if (useEmu) {
  try {
    connectAuthEmulator(auth, `http://${authHost}:${authPort}`);
  } catch {}
  try {
    connectFirestoreEmulator(db, fsHost, fsPort);
  } catch {}
}

export default app;
