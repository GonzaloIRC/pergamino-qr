// filepath: src/utils/rut.js
// Utilidades simples para RUT chileno (normalizar y validar dígito verificador)
export function normalizeRut(raw) {
  if (!raw) return '';
  const s = String(raw).replace(/\./g, '').replace(/\s+/g, '').toUpperCase();
  // Mantiene guión; separa cuerpo y dv
  const m = s.match(/^([0-9]+)-?([0-9K])$/);
  if (!m) return s;
  return `${m[1]}-${m[2]}`;
}

export function isValidRut(rut) {
  const n = normalizeRut(rut);
  const m = n.match(/^([0-9]+)-([0-9K])$/);
  if (!m) return false;
  const body = m[1];
  const dv = m[2];
  let sum = 0, mul = 2;
  for (let i = body.length - 1; i >= 0; i--) {
    sum += parseInt(body[i], 10) * mul;
    mul = mul === 7 ? 2 : mul + 1;
  }
  const res = 11 - (sum % 11);
  const dvCalc = res === 11 ? '0' : res === 10 ? 'K' : String(res);
  return dvCalc === dv;
}
