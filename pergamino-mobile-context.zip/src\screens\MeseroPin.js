// filepath: src/screens/MeseroPin.js
import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';

const PIN = '1234'; // MVP — mover a remote config/claim más adelante

export default function MeseroPin({ onOk, onCancel }) {
  const [pin, setPin] = useState('');
  const check = () => {
    if (pin === PIN) return onOk?.();
    Alert.alert('PIN incorrecto', 'Intenta nuevamente');
  };
  return (
    <View style={{ flex: 1, padding: 20, gap: 12, alignItems: 'stretch', justifyContent: 'center' }}>
      <Text style={{ fontSize: 20, fontWeight: '700', textAlign: 'center' }}>Acceso Mesero</Text>
      <TextInput
        placeholder="PIN"
        value={pin}
        onChangeText={setPin}
        keyboardType="number-pad"
        secureTextEntry
        style={{ borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 12 }}
      />
      <Button title="Entrar" onPress={check} />
      <View style={{ height: 8 }} />
      <Button title="Cancelar" onPress={() => onCancel?.()} />
    </View>
  );
}
