// filepath: src/screens/RegisterClient.js
import React, { useState } from 'react';
import { View, Text, TextInput, Button, ScrollView, StatusBar, StyleSheet, Alert } from 'react-native';
import { auth, db } from '../services/firebase/app';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp, getDoc } from 'firebase/firestore';

export default function RegisterClient({ onDone }) {
  const [form, setForm] = useState({
    nombre: '',
    apellido: '',
    dni: '',
    email: '',
    nacimiento: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);

  const onChange = (k, v) => setForm((s) => ({ ...s, [k]: v }));

  async function handleRegister() {
    if (!form.nombre || !form.apellido || !form.dni || !form.email || !form.password) {
      Alert.alert('Campos requeridos', 'Completa nombre, apellido, DNI, email y contraseña.');
      return;
    }
    setLoading(true);
    try {
      // DNI único en colección clientes
      const ref = doc(db, 'clientes', form.dni);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        Alert.alert('DNI en uso', 'Ya existe un cliente registrado con ese DNI.');
        setLoading(false);
        return;
      }

      // Crear usuario auth (email+pass)
      await createUserWithEmailAndPassword(auth, form.email, form.password);

      // Documento del cliente
      await setDoc(ref, {
        nombre: form.nombre,
        apellido: form.apellido,
        dni: form.dni,
        email: form.email,
        nacimiento: form.nacimiento || null,
        puntos: 0,
        categoria: 'cliente',
        walletActivo: true,
        fechaRegistro: serverTimestamp(),
      });

      Alert.alert('OK', 'Registro completado');
      onDone?.();
    } catch (e) {
      console.error(e);
      Alert.alert('Error', e?.message || 'No se pudo registrar');
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <StatusBar />
      <Text style={styles.title}>Registro de Cliente</Text>

      <TextInput style={styles.input} placeholder="Nombre" value={form.nombre} onChangeText={(t) => onChange('nombre', t)} />
      <TextInput style={styles.input} placeholder="Apellido" value={form.apellido} onChangeText={(t) => onChange('apellido', t)} />
      <TextInput style={styles.input} placeholder="DNI/RUT" value={form.dni} onChangeText={(t) => onChange('dni', t)} autoCapitalize="characters" />
      <TextInput style={styles.input} placeholder="Email" value={form.email} onChangeText={(t) => onChange('email', t)} keyboardType="email-address" autoCapitalize="none" />
      <TextInput style={styles.input} placeholder="Fecha de nacimiento (YYYY-MM-DD)" value={form.nacimiento} onChangeText={(t) => onChange('nacimiento', t)} />
      <TextInput style={styles.input} placeholder="Contraseña" value={form.password} onChangeText={(t) => onChange('password', t)} secureTextEntry />

      <View style={{ height: 12 }} />
      <Button title={loading ? 'Registrando...' : 'Registrar'} onPress={handleRegister} disabled={loading} />
      <View style={{ height: 12 }} />
      <Button title="Volver" onPress={() => onDone?.()} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 16, textAlign: 'center' },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    fontSize: 16,
    backgroundColor: '#fff',
  },
});
