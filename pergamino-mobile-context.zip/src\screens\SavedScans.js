// filepath: src/screens/SavedScans.js
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Button } from 'react-native';
import { db } from '../services/firebase/app';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';

export default function SavedScans({ onDone }) {
  const [items, setItems] = useState([]);

  useEffect(() => {
    const q = query(collection(db, 'scans'), orderBy('createdAt', 'desc'), limit(20));
    const unsub = onSnapshot(q, (snap) => {
      const arr = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setItems(arr);
    });
    return () => unsub();
  }, []);

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 20, fontWeight: '700', marginBottom: 12 }}>Últimos escaneos</Text>
      <FlatList
        data={items}
        keyExtractor={(it) => it.id}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        renderItem={({ item }) => (
          <View style={{ padding: 12, backgroundColor: '#fff', borderRadius: 10 }}>
            <Text style={{ fontWeight: '700' }}>{item.type || 'qr'}</Text>
            <Text numberOfLines={2} style={{ color: '#333' }}>{String(item.data || item.raw || '')}</Text>
            <Text style={{ color: '#666', fontSize: 12 }}>{item.createdAt?.toDate?.().toISOString?.() || item.ts || ''}</Text>
          </View>
        )}
        ListEmptyComponent={<Text style={{ color: '#666' }}>Vacío</Text>}
      />
      <View style={{ height: 12 }} />
      <Button title="Volver" onPress={() => onDone?.()} />
    </View>
  );
}
